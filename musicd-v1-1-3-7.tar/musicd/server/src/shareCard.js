/**
 * Generate a landscape PNG share card for an album.
 * Layout (1200 × 720):
 *   ┌──────────────────────────────────────────────┐
 *   │           Released YYYY  ◄── aligned with    │
 *   │ [art]     Album Name        top of art       │
 *   │ [art]     (wraps up to 3)                    │
 *   │ [art]     by Artist Name                     │
 *   │ [art]     (wraps up to 2)                    │
 *   │                                              │
 *   │  [ GENRE1 ] [ GENRE2 ] [ GENRE3 ]   MusicD   │
 *   └──────────────────────────────────────────────┘
 *
 * Text block hugs the top of the album-art "card" rather than floating from
 * the card edge, mirroring Roon's share-card layout.
 */
const sharp = require('sharp');
const db = require('./db');

const W = 1200, H = 720;
const ART_SIZE = 460;
const ART_X = 60;
const ART_Y = (H - ART_SIZE) / 2;        // vertically centred art
const TEXT_X = ART_X + ART_SIZE + 60;
const TEXT_RIGHT_PAD = 50;
const TEXT_MAX_W = W - TEXT_X - TEXT_RIGHT_PAD;

// Genre pill geometry
const PILL_HEIGHT = 52;
const PILL_PAD_X = 26;
const PILL_GAP = 14;
const PILL_RADIUS = 6;
const PILL_FONT_SIZE = 22;

// Title typography
const TITLE_FONT = 44;
const TITLE_LINE_H = 54;
const TITLE_MAX_LINES = 3;

// Artist typography (now wraps too)
const ARTIST_FONT = 30;
const ARTIST_LINE_H = 38;
const ARTIST_MAX_LINES = 2;

function escXml(s) {
  return String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&apos;');
}
function formatDate(year) {
  if (!year) return '';
  return `Released ${year}`;
}
function splitGenres(genreStr) {
  if (!genreStr) return [];
  return genreStr.split(/[,;\/]/).map(g => g.trim()).filter(Boolean).slice(0, 3);
}

function approxTextWidth(text, fontSizePx, letterSpacing = 0) {
  return Math.max(0, text.length) * fontSizePx * 0.66 + Math.max(0, text.length - 1) * letterSpacing;
}

// Per-character width factor for body text (heavy sans @ tight letter-spacing).
// Different fonts/weights would benefit from different factors; 0.55 errs slightly
// generous so we never overrun the right edge.
function bodyCharWidth(fontSizePx) {
  return fontSizePx * 0.55;
}

// Greedy word-wrap. Returns up to maxLines lines that fit within maxWidthPx;
// last line gets ellipsised if input was longer.
function wrapText(text, fontSizePx, maxWidthPx, maxLines, prefix = '') {
  // If a prefix is supplied (e.g. "by ") we reserve room for it on the FIRST line
  const charW = bodyCharWidth(fontSizePx);
  const maxChars = Math.floor(maxWidthPx / charW);
  const prefixLen = prefix ? prefix.length : 0;
  const words = String(text || '').split(/\s+/).filter(Boolean);
  const lines = [];
  let current = '';
  let onFirstLine = true;
  const limitForLine = () => onFirstLine ? Math.max(1, maxChars - prefixLen) : maxChars;

  for (const word of words) {
    const candidate = current ? current + ' ' + word : word;
    if (candidate.length <= limitForLine()) {
      current = candidate;
    } else {
      if (current) { lines.push(current); onFirstLine = false; }
      if (word.length > maxChars) {
        let remaining = word;
        while (remaining.length > maxChars) {
          lines.push(remaining.slice(0, maxChars - 1) + '…');
          remaining = remaining.slice(maxChars - 1);
          onFirstLine = false;
          if (lines.length >= maxLines) break;
        }
        current = remaining;
      } else {
        current = word;
      }
    }
    if (lines.length >= maxLines) break;
  }
  if (current && lines.length < maxLines) lines.push(current);

  const consumed = lines.join(' ').replace(/…/g, '');
  if (consumed.length < text.replace(/\s+/g, ' ').trim().length) {
    const last = lines[lines.length - 1] || '';
    const trimmed = last.length > 1 ? last.slice(0, Math.max(1, last.length - 1)) + '…' : '…';
    lines[lines.length - 1] = trimmed;
  }
  return lines;
}

async function generateForAlbum(albumId) {
  const database = db.get();
  const album = database.prepare(`
    SELECT id, title, album_artist, year, genre, cover_art FROM albums WHERE id = ?
  `).get(albumId);
  if (!album) throw new Error('Album not found');

  const released = formatDate(album.year);
  const rawTitle = album.title || '';
  const rawArtist = album.album_artist || '';
  const genres = splitGenres(album.genre).map(g => g.toUpperCase());

  const titleLines = wrapText(rawTitle, TITLE_FONT, TEXT_MAX_W, TITLE_MAX_LINES);
  const artistLines = wrapText(rawArtist, ARTIST_FONT, TEXT_MAX_W, ARTIST_MAX_LINES, 'by ');

  let blurredBg = null, artImage = null;
  if (album.cover_art) {
    const artBuf = Buffer.from(album.cover_art);
    blurredBg = await sharp(artBuf)
      .resize(W, H, { fit: 'cover' })
      .blur(50)
      .modulate({ brightness: 0.32, saturation: 1.1 })
      .toBuffer();
    artImage = await sharp(artBuf)
      .resize(ART_SIZE, ART_SIZE, { fit: 'cover' })
      .toBuffer();
  }

  // ── Vertical layout ───────────────────────────────────────────────────────
  // Release date baseline aligned with the top of the album art.
  // SVG <text> y is the baseline, so add the released-text font-size as offset
  // from ART_Y so the cap-height of "Released YYYY" sits flush with the art top.
  const RELEASED_FONT = 28;
  const releasedY   = ART_Y + RELEASED_FONT;       // baseline ≈ top of art
  const titleStartY = releasedY + 56;              // space below release date
  const titleEndY   = titleStartY + (titleLines.length - 1) * TITLE_LINE_H;
  const artistStartY = titleEndY + 56;             // space between title and artist
  const artistEndY   = artistStartY + (artistLines.length - 1) * ARTIST_LINE_H;

  // Genre row sits a comfortable gap below the artist block AND a generous
  // distance from the bottom — pick whichever places it lower so we always
  // have breathing room above the pills, even with short text content.
  const PILL_GAP_FROM_ARTIST = 90;     // bigger gap requested
  const PILL_BOTTOM_FROM_EDGE = 70;
  const PILL_ROW_Y = Math.max(
    artistEndY + PILL_GAP_FROM_ARTIST,
    H - PILL_BOTTOM_FROM_EDGE - PILL_HEIGHT,
  );

  // ── Genre pills — centred across the full card width ─────────────────────
  const PILL_LETTER_SPACING = 2;
  const pillWidths = genres.map(g => {
    const textW = approxTextWidth(g, PILL_FONT_SIZE, PILL_LETTER_SPACING);
    return Math.ceil(textW + PILL_PAD_X * 2);
  });
  const totalPillsW = pillWidths.reduce((a, w) => a + w, 0) + PILL_GAP * Math.max(0, genres.length - 1);
  let pillX = (W - totalPillsW) / 2;

  const pillSvg = genres.map((g, idx) => {
    const w = pillWidths[idx];
    const x = pillX;
    pillX += w + PILL_GAP;
    return `
      <rect x="${x}" y="${PILL_ROW_Y}" width="${w}" height="${PILL_HEIGHT}"
            rx="${PILL_RADIUS}" ry="${PILL_RADIUS}"
            fill="#5b7fff" />
      <text x="${x + w / 2}" y="${PILL_ROW_Y + PILL_HEIGHT / 2 + PILL_FONT_SIZE / 3}"
            text-anchor="middle"
            font-family="sans-serif" font-size="${PILL_FONT_SIZE}"
            font-weight="700" letter-spacing="${PILL_LETTER_SPACING}"
            fill="white">${escXml(g)}</text>`;
  }).join('');

  // Title lines
  const titleSvg = titleLines.map((line, i) =>
    `<text x="${TEXT_X}" y="${titleStartY + i * TITLE_LINE_H}" class="title">${escXml(line)}</text>`
  ).join('\n    ');

  // Artist lines — first line gets the "by " prefix in muted weight.
  // Wrapped continuation lines get the same name-style indented under the prefix.
  const artistSvg = artistLines.map((line, i) => {
    if (i === 0) {
      return `<text x="${TEXT_X}" y="${artistStartY}" class="by">by <tspan class="name">${escXml(line)}</tspan></text>`;
    }
    // Continuation lines: same x, in the bold-name colour
    return `<text x="${TEXT_X}" y="${artistStartY + i * ARTIST_LINE_H}" class="by"><tspan class="name">${escXml(line)}</tspan></text>`;
  }).join('\n    ');

  // MusicD wordmark — bottom-right, vertically aligned with pill row centre
  const LOGO_FONT = 34;
  const LOGO_Y = PILL_ROW_Y + PILL_HEIGHT / 2 + LOGO_FONT / 3;
  const LOGO_X_RIGHT = W - 50;

  const svg = `<svg width="${W}" height="${H}" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <style>
        .released { fill: rgba(255,255,255,0.6); font-family: sans-serif; font-size: ${RELEASED_FONT}px; font-weight: 500; letter-spacing: 0.3px; }
        .title    { fill: white; font-family: sans-serif; font-size: ${TITLE_FONT}px; font-weight: 800; letter-spacing: -0.5px; }
        .by       { fill: rgba(255,255,255,0.7); font-family: sans-serif; font-size: ${ARTIST_FONT}px; font-weight: 400; }
        .by .name { fill: white; font-weight: 700; }
        .logo-music { fill: rgba(255,255,255,0.92); font-family: sans-serif; font-size: ${LOGO_FONT}px; font-weight: 800; letter-spacing: -0.5px; }
        .logo-d     { fill: #5b7fff; font-family: sans-serif; font-size: ${LOGO_FONT}px; font-weight: 800; letter-spacing: -0.5px; }
      </style>
    </defs>
    <text x="${TEXT_X}" y="${releasedY}" class="released">${escXml(released)}</text>
    ${titleSvg}
    ${artistSvg}
    ${pillSvg}
    <text x="${LOGO_X_RIGHT}" y="${LOGO_Y}" text-anchor="end" class="logo-music">Music<tspan class="logo-d">D</tspan></text>
  </svg>`;

  const layers = [];
  if (blurredBg) layers.push({ input: blurredBg, top: 0, left: 0 });
  if (artImage)  layers.push({ input: artImage,  top: ART_Y, left: ART_X });
  layers.push({ input: Buffer.from(svg), top: 0, left: 0 });

  const final = await sharp({
    create: { width: W, height: H, channels: 4, background: '#0a0a10' },
  }).composite(layers).png({ quality: 92 }).toBuffer();
  return final;
}

async function generateForCurrent() {
  const playerState = require('./playerState');
  const state = playerState.getState();
  const track = state.currentTrack;
  if (!track) throw new Error('No track playing');
  const database = db.get();
  const album = database.prepare(`
    SELECT id FROM albums WHERE title = ? AND album_artist = ? LIMIT 1
  `).get(track.album, track.album_artist);
  if (!album) throw new Error('Album not found in DB');
  return generateForAlbum(album.id);
}

module.exports = { generateForAlbum, generateForCurrent };
